﻿namespace Boxinator_API.Model.Const
{
    public enum AccountType
    {
        GUEST,
        REGISTERED_USER,
        ADMINISTRATOR
    }
}
