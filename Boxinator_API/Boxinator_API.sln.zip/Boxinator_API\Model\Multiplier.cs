﻿using System;

namespace Boxinator_API.Model
{
    public class Multiplier
    {
        public int MultiplierId { get; set; }
        public string Country { get; set; }
        public int MultiplierNumber { get; set; }
        public DateTime DateOfChange { get; set; }
    }
}
