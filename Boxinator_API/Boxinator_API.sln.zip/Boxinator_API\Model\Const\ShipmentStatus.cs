﻿namespace Boxinator_API.Model.Const
{
    public enum ShipmentStatus
    {
        CREATED,
        RECIEVED,
        INTRASIT,
        COMPLETED,
        CANCELLED
    }
}
