﻿namespace Boxinator_API.Model.Const.DTO.GuestUser
{
    public class GuestUserCreateDTO
    {
        public string Email { get; set; }
    }
}
