﻿namespace Boxinator_API.Model.Const.DTO.GuestUser
{
    public class GuestUserUpdateDTO
    {
        public int guestUserId { get; set; }
        public string Email { get; set; }
    }
}
